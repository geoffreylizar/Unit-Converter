# Define lists to separate untis into groups

# Units of time
time_units = ["second", "jiffy", "svedberg", "shake", "minute", "moment", "ke", "hour", "day", "decasecond", 
              "hectosecond", "kilosecond", "megasecond", "gigasecond", "terasecond", "petasecond", "exasecond", 
              "zettasecond", "yottasecond", "decisecond", "centisecond", "millisecond", "microsecond", "nanosecond", 
              "picosecond", "femtosecond", "attosecond", "zeptosecond", "yoctosecond", "week", "fortnight", 
              "lunar month", "year", "decade", "score", "century", "millennium", "epoch", "eon", "aeon", 
              "biennium", "triennium", "quadrennium", "olympiad", "lustrum", "indiction", "jubilee", "megannum", 
              "galactic year"]

#units of time best defined by seconds
second_units = ["second", "jiffy", "svedberg", "shake", "minute", "moment", "ke", "hour", "decasecond", "hectosecond", 
                "kilosecond", "megasecond", "gigasecond", "terasecond", "petasecond", "exasecond", "zettasecond", 
                "yottasecond", "decisecond", "centisecond", "millisecond", "microsecond", "nanosecond", "picosecond", 
                "femtosecond", "attosecond", "zeptosecond", "yoctosecond"]

#units of time best defined by days
day_units = ["day", "week", "fortnight", "lunar month"]

#units of time best defined by years
year_units = ["year", "decade", "score", "century", "millennium", "epoch", "eon", "aeon", "biennium", "triennium", 
              "quadrennium", "olympiad", "lustrum", "indiction", "jubilee", "megannum", "galactic year"]

# Units of length
length_units = ["meter", "thou", "mil", "line", "inch", "foot", "yard", "mile", "micron", "fermi", "decameter", 
                "hectometer", "kilometer", "megameter", "gigameter", "terameter", "petameter", "exameter", "zettameter", 
                "yottameter", "decimeter", "centimeter", "millimeter", "micrometer", "nanometer", "picometer", 
                "femtometer", "attometer", "zeptometer", "yoctometer"]

# Units of mass
mass_units = ["gram", "pound", "ounce", "carat", "ton", "metric ton", "grain", "stone", "dram", "decagram", 
              "hectogram", "kilogram", "megagram", "gigagram", "teragram", "petagram", "exagram", "zettagram", 
              "yottagram", "decigram", "centigram", "milligram", "microgram", "nanogram", "picogram", "femtogram", 
              "attogram", "zeptogram", "yoctogram"]

# Units of electrical current
electrical_units = ["amp", "biot", "decaamp", "hectoamp", "kiloamp", "megaamp", "gigaamp", "teraamp", "petaamp", 
                    "exaamp", "zettaamp", "yottaamp", "deciamp", "centiamp", "milliamp", "microamp", "nanoamp", "picoamp", 
                    "femtoamp", "attoamp", "zeptoamp", "yoctoamp"]

# Units of thermodynamic temperature
temperature_units = ["celsius", "fahrenheit", "kelvin"]

# Denotes units in the SI official list (Celsius instead of Kelvin)
standard_units = ["second", "meter", "gram", "amp", "celsius"]

# LIST OF LISTS
list_of_lists = [time_units, length_units, mass_units, electrical_units, temperature_units]

# Conversion dictionary
standard_conversion_dictionary = {"yotta": (10 ** 24), "zetta": (10 ** 21), "exa": (10 ** 18), "peta": (10 ** 15), 
                                  "tera": (10 ** 12), "giga": (10 ** 9), "mega": (10 ** 6), "kilo": (10 ** 3), 
                                  "hecto": (10 ** 2), "deca": (10 ** 1), "deci": (10 ** -1), "centi": (10 ** -2), 
                                  "milli": (10 ** -3), "micro": (10 ** -6), "nano": (10 ** -9), "pico": (10 ** -12), 
                                  "femto": (10 ** -15), "atto": (10 ** -18), "zepto": (10 ** -21), "yocto": (10 ** -24)}

# list of non-standard time units
non_standard_time = ["jiffy", "svedberg", "shake", "minute", "moment", "ke", "hour", "day", "week", "fortnight", 
                     "lunar month", "year", "decade", "score", "century", "millennium", "epoch", "eon", "aeon", 
                     "biennium", "triennium", "quadrennium", "olympiad", "lustrum", "indiction", "jubilee", "megannum", 
                     "galactic year"]

# dictionary of conversion factors converting to seconds
non_standard_to_seconds = {"second": (1), "day": (86400), "year": (86400 * 365.25), "jiffy": ((10 ** -24) * 3), 
                           "svedberg": (10 ** -13), "shake": (10 ** -8), "minute": (60), "moment": (90), "ke": (864), 
                           "hour": (3600)}

# dictionary of conversion factors converting to days
non_standard_to_days = {"day": (1), "second": (1 / 86400), "year": (365.25), "week": (7), "fortnight": (14), 
                        "lunar month": (29.5)}

# dictionary of conversion factors converting to years
non_standard_to_years = {"year": (1), "second": (1 / (86400 * 365.25)), "day": (1 / 365.25), "decade": (10), 
                         "score": (20), "century": (10 ** 2), "millennium": (10 ** 3), "epoch": (2 * (10 ** 4)), 
                         "eon": (10 ** 5), "aeon": (10 ** 6), "biennium": (2), "triennium": (3), "quadrennium": (4), 
                         "olympiad": (4), "lustrum": (5), "indiction": (15), "jubilee": (50), "megannum": (10 ** 6), 
                         "galactic year": (23 * (10 ** 7))}

# Non-standard conversion dictionaries
non_standard_length = {"thou": (1 / (39.3700787 * (10 ** 3))), "mil": (1 / (39.3700787 * (10 ** 3))), 
                       "line": ((1 / 39.3700787) / 12), "inch": (1 / 39.3700787), "foot": (12 / 39.3700787), 
                       "yard": (36 / 39.3700787), "mile": (633600 / 393.700787), "micron": (10 ** -6), 
                       "fermi": (10 ** -15)}

non_standard_mass = {"pound": (453.592), "ounce": (28.3495), "carat": (1 / 5), "ton": (907184.74), 
                     "metric ton": (1016047), "grain": (453.592 / 7000), "stone": (453.592 * 14), 
                     "dram": (28.3495 / 16)}

non_standard_electrical = {"biot": 10}

unit_type_dict = {"meter": non_standard_length, "gram": non_standard_mass, "amp": non_standard_electrical}

plural_exception_dict = {"feet": "foot", "centuries": "century", "inches": "inch", "celsius": "celsius", 
                         "millennia": "millennium", "biennia": "biennium", "triennia": "triennium", 
                         "quadrennia": "quadrennium", "lustra": "lustrum", "meganna": "megannum"}

plural_exception_list = ["foot", "century", "inch", "celsius", "millennium", "biennium", "triennium", "quadrennium", 
                         "lustrum", "megannum"]
                         

from math import log10, floor

def execute_program(value_in = 0, starting_units = "", ending_units = ""):
    """Executes the full conversion and prints the results. 
    
    Parameters
    ----------
    value_in : int or float
        Starting value for the conversion. 
    starting_units : string
        Units to be converted from.
    ending_units : string
        Units to be converted to.
    
    Returns
    -------
    print_statement : string
        Returns either an error message or the final conversion string. 
    """
    
    #standardize unit in and out
    starting_units = standardize_unit(starting_units)
    ending_units = standardize_unit(ending_units)
    print_statement = ""
    
    # Bypasses the conversion if the starting and ending units are the same. Prints a special message.
    if starting_units == ending_units:
        print_statement = (str(value_in) + " " + finalize_units(value_in, starting_units) + " is equal to " + str(value_in) + " " + 
              finalize_units(value_in, ending_units) + ". Because duh.")
    else:

        # check if standard unit with or without prefix
        starting_is_standard = check_standard(starting_units)
        ending_is_standard = check_standard(ending_units)

        # check that units are of same type
        same_type = False
        for unit_list in list_of_lists:
            if starting_units in unit_list and ending_units in unit_list:
                same_type = True
                unit_key = unit_list[0]
                break
            else:
                same_type = False

        # continues the program if units are same type. Otherwise throws up an error.
        if same_type == True:

            # perform conversion
            temp_value = convert(starting_units, value_in, starting_is_standard, unit_key, False) # Converts to SI standard
            value_out = convert(ending_units, temp_value, ending_is_standard, unit_key, True) # Converts to final units

            # Prints conversion for the user
            print_statement = "{} {} is equal to {} {}.".format(str(value_in), finalize_units(value_in, starting_units), 
                                                   str(value_out), finalize_units(value_out, ending_units))

            if value_out == value_in:
                print_statement = print_statement + "Congratulations. You accomplished nothing."
        # If the units were different types (i.e. seconds to meters)
        else:
            print_statement = "Those units are not compatible"
    return print_statement


def convert(units, start_value, unit_is_standard, unit_type, reverse):
    """Converts to and from SI unit for respective unit type. 
    
    Parameters
    ----------
    units : string
        Designates the units to be converted to or from. 
    start_value : int or float
        Starting value of the one-way conversion.
    unit_is_standard : boolean
        If True, units begins with a standard prefix. If False, units is non-standard.
    unit_type : string
        Determined automatically; one of the following values: "second, "celsius", "meter", "gram", "amp". Used to determine conversion
        factor dictionary
    reverse : boolean
        If False, converts to SI standard unit (meter, gram, amp, celsius, or second). If True, converts to final units.
    
    Returns
    -------
    final_value : float
        Result of the one-way conversion. 
    """
        
    final_value = 0
    conversion_factor = 1
    
    # If unit is SI or has standard prefix, checks for standard conversion factor
    if unit_is_standard == True:
        # Finds the conversion factor and performs the conversion
        final_value = start_value * find_conversion_factor(units, reverse)
    else:
        if units in temperature_units:
            # Converting to Celsius
            if reverse == False:
                if units == "fahrenheit":
                    final_value = (start_value - 32) * 5 / 9
                elif units == "kelvin":
                    final_value = start_value - 273.15
                elif units == "celsius":
                    final_value = start_value
            # Converting from Celsius
            elif reverse == True:
                if units == "fahrenheit":
                    final_value = (start_value * 9 / 5) + 32
                elif units == "kelvin":
                    final_value = start_value + 273.15
                elif units == "celsius":
                    final_value = start_value
        else:
            if units in time_units:
                if units in second_units:
                    #convert from seconds
                    conversion_factor = non_standard_to_seconds[units]
                elif units in day_units:
                    #convert from seconds
                    conversion_factor = non_standard_to_seconds["day"]
                    #convert to days
                    conversion_factor = conversion_factor * non_standard_to_days[units]
                elif units in year_units:
                    #convert from seconds
                    conversion_factor = non_standard_to_seconds["year"]
                    #convert to years
                    conversion_factor = conversion_factor * non_standard_to_years[units]
            else:
                # Picks proper conversion dictionary
                factor_dict = unit_type_dict[unit_type]
                # Picks correct conversion factor from said dictionary
                conversion_factor = factor_dict[units]
            
            # If converting to SI, reverse is False. If converting to final units, reverse is True. Flips conversion factor
            if reverse == True:
                conversion_factor = 1 / conversion_factor
            
            # Performs conversion
            final_value = start_value * conversion_factor

    # Rounding to the proper number of significant figures
    if units in mass_units:
        # Limiting significant figures: grams to pounds (6 figs)
        final_value = round_sig(final_value, 6)
    elif units in length_units:
        # Limiting significant figures: meters to inches (9 figs)
        final_value = round_sig(final_value, 9)
    else:
        # Weird rounding errors occur with 16+ significant figures
        final_value = round_sig(final_value, 15)
    
    return final_value


def find_conversion_factor(unit_type, invert):
    """[What the function does]. 
    
    Parameters
    ----------
    unit_type : string
        The type of units being converted. 
    invert : boolean
        If True, converts the factor to 1/x.
    
    Returns
    -------
    conversion_factor : float
        Conversion factor to be used in the convert function. 
    """
    
    conversion_factor = 1
    if unit_type in standard_units: # No prefix on units
        conversion_factor = 1
    else:
        # Isolates the prefix
        for unit in standard_units:
            if unit in unit_type:
                prefix = unit_type.replace(unit, "")
        # Picks the conversion factor based on prefix
        conversion_factor = standard_conversion_dictionary[prefix]
    
    # If converting to SI, invert is False. If converting to final units, invert is True. Flips conversion factor
    if invert == True:
        conversion_factor = 1 / conversion_factor
        
    return conversion_factor


def check_standard(unit_type):
    """Checks if units are standard SI with or without prefix. 
    
    Parameters
    ----------
    unit_type : string
        Units being checked. 
    
    Returns
    -------
    standard : boolean
        Returns True if unit_type is SI or has a standard prefix. 
    """
    
    standard = False
    # Loops through the list of standard units to check if unit_type is SI with or without prefix.
    for unit in standard_units:
        if unit in unit_type:
            standard = True
            break
        else:
            standard = False
    return standard

def standardize_unit(unit_input):
    """Takes plural or capital inputs and converts to a form useable by this module. 
    
    Parameters
    ----------
    unit_input : string
        Units being standardized. 
    
    Returns
    -------
    out_unit : string
        Singular, lowercase version of unit_input. 
    """
    
    # convert to lowercase
    out_unit = unit_input.lower()
    
    # looks for plurals
    if out_unit.endswith("s") or out_unit in plural_exception_dict:
        # Checks for exceptions like foot/feet, inch/inches, etc.
        if out_unit in plural_exception_dict:
            out_unit = plural_exception_dict[out_unit]
        else:
            out_unit = out_unit.rstrip("s")
    
    # changes [prefix]ampere to [prefix]amp
    if out_unit.endswith("ere"):
        out_unit = out_unit.rstrip("ere")
    return out_unit

def finalize_units(value, units):
    """Re-pluralizes and makes grammatically correct the units to be displayed to the user. 
    
    Parameters
    ----------
    value : float
        Final value after conversion has been performed. 
    units : string
        Standard form of units to be printed.
    
    Returns
    -------
    units_out : string
        Grammatically correct version of units to be printed. 
    """
    
    units_out = ""
    if units == "fahrenheit" or units == "celsius":
        if value == 1:
            units_out = "degree " + units
        elif value != 1:
            units_out = "degrees " + units
    else:
        if value == 1:
            units_out = units
        elif value != 1:
            # Checks for exceptions like foot/feet, inch/inches, etc.
            if units in plural_exception_list:
                for key in plural_exception_dict:
                    if plural_exception_dict[key] == units:
                        units_out = key
            else:
                units_out = units + "s"
    return units_out

def round_sig(x, sig = 2):
    """Rounds a value (x) to the desired number of significat figures (sig). Borrowed. 
    
    Parameters
    ----------
    x : int or float
        Value before rounding. 
    sig : int
        Number of significant figures wanted.
    
    Returns
    -------
    float
        Rounded units. 
    """
    
    return round(x, sig - int(floor(log10(abs(x))))-1)