def test_execute_program():
    assert execute_program(1, "day", "second") == "1 day is equal to 86400.0 seconds."
    assert execute_program(1, "kilometer", "feet") == "1 kilometer is equal to 3280.83989 feet."
    assert execute_program(100, "Celsius", "Fahrenheit") == "100 degrees celsius is equal to 212.0 degrees fahrenheit."
    assert execute_program(1, "Kilogram", "milligrams") == "1 kilogram is equal to 1000000.0 milligrams."
    assert execute_program(1, "biot", "ampere") == "1 biot is equal to 10.0 amps."
    assert execute_program(1, "femtogram", "centimeter") == "Those units are not compatible"
    assert execute_program(1, "megannum", "aeon") == "1 megannum is equal to 1.0 aeon.Congratulations. You accomplished nothing."
    assert execute_program(1, "kilometer", "kilometer") == "1 kilometer is equal to 1 kilometer. Becaue duh."
    
def test_convert():
    assert convert("minute", 5, False, "second", False) == 300
    assert convert("kilogram", 3, True, "gram", False) == 3000
    assert convert("centimeter", 100, True, "meter", False) == 1
    assert convert("kelvin", 274.15, False, "celsius", False) == 1
    assert convert("biot", 5, False, "amp", False) == 50
    assert convert("decimeter", 1, True, "meter", True) == 10