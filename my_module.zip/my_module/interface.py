import tkinter as tk
from functions import *

# Set the root and define the title
root = tk.Tk()
root.title("Unit Converter")

# Creates labels for buttons and spacers to make it look pretty
start_units_label = tk.Label(root, text = "Choose Starting Units")
end_units_label = tk.Label(root, text = "Choose Ending Units")
unit_value_label = tk.Label(root, text = "Type Value")
spacer1 = tk.Label(root, text = "   ")
spacer2 = tk.Label(root, text = "   ")

# Creates input selections in the form of text boxes
start_units_input = tk.Entry(root)
end_units_input = tk.Entry(root)
unit_value_input = tk.Entry(root)

# Sets default values for the inputs
unit_value_input.insert(0, "0")
start_units_input.insert(0, "kilogram")
end_units_input.insert(0, "kilogram")

# Places the labels, spacers, and inputs in the proper place graphically in the UI
start_units_label.grid(row = 0, column = 0)
end_units_label.grid(row = 0, column = 4)
unit_value_label.grid(row = 0, column = 2)
spacer1.grid(row = 0, column = 1)
spacer2.grid(row = 0, column = 3)
start_units_input.grid(row = 1, column = 0)
end_units_input.grid(row = 1, column = 4)
unit_value_input.grid(row = 1, column = 2)

# Function to run when button is clicked as per tkinter requirements
def run_function():
    # Fetches the inputs and stores them
    units_in = start_units_input.get()
    units_out = end_units_input.get()
    # Corrects for empty string
    if unit_value_input.get() == "":
        unit_value = 0
    else:
        unit_value = int(unit_value_input.get())
    
    # Performs the conversion and stores it as a string
    message = execute_program(unit_value, units_in, units_out)
    
    # Creates a popup window that displays the conversion
    tk.messagebox.showinfo("Conversion", message)

# Creates and places a button to execute the conversion
performConversion = tk.Button(root, text = "Convert Now", padx = 50, pady = 5, fg = "white", bg = "black", command = run_function)
performConversion.grid(row = 2, column = 2)

# Creates the main loop to execute the program
root.mainloop()
